from semantic_checker import SemanticAnalyzer  # Import the semantic analyzer

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens  # List of tokens
        self.pos = 0  # Current position in token list
        self.semantic = SemanticAnalyzer()  # Add semantic analyzer
        self.intermediate_code = []         # To store three-address code (TAC)

    def current_token(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None  # End of input

    def consume(self):
        """Advance to the next token."""
        self.pos += 1

    def match(self, token_type):
        """Consume the current token if it matches the expected type."""
        if self.current_token() and self.current_token()[0] == token_type:
            self.consume()
        else:
            raise SyntaxError(f"Expected {token_type}, found {self.current_token()}")

    def parse(self):
        """Start parsing from the top-most non-terminal <program>."""
        self.program()

    def program(self):
        """<program> ::= <stmt_list>"""
        self.stmt_list()

    def stmt_list(self):
        """<stmt_list> ::= <stmt> <stmt_list> | ε"""
        while self.current_token() and self.current_token()[0] != 'RBRACE':  # End of program or block
            self.stmt()

    def stmt(self):
        """<stmt> ::= <decl_stmt> | <assign_stmt> | <if_stmt> | <while_stmt> | <print_stmt>"""
        if self.current_token()[0] == 'INT':
            self.decl_stmt()
        elif self.current_token()[0] == 'ID':
            self.assign_stmt()
        elif self.current_token()[0] == 'IF':
            self.if_stmt()
        elif self.current_token()[0] == 'WHILE':
            self.while_stmt()
        elif self.current_token()[0] == 'PRINT':
            self.print_stmt()
        else:
            raise SyntaxError(f"Unexpected token: {self.current_token()}")

    def decl_stmt(self):
        """<decl_stmt> ::= 'int' ID ';'"""
        self.match('INT')
        self.match('ID')
        self.match('SEMICOLON')

    def assign_stmt(self):
        # """<assign_stmt> ::= ID '=' <expr> ';'"""
        # self.match('ID')
        # self.match('ASSIGN')
        # self.expr()
        # self.match('SEMICOLON')
        """<assign_stmt> ::= ID '=' <expr> ';'"""
        var_name = self.current_token()[1]
        self.semantic.check_variable(var_name)
        self.match('ID')
        self.match('ASSIGN')
        expr_result = self.expr()  # this will return a temp var or literal
        self.match('SEMICOLON')
        self.intermediate_code.append(f"{var_name} = {expr_result}")


    def if_stmt(self):
        """<if_stmt> ::= 'if' '(' <cond> ')' '{' <stmt_list> '}'"""
        self.match('IF')
        self.match('LPAREN')
        self.cond()
        self.match('RPAREN')
        self.match('LBRACE')
        self.stmt_list()
        self.match('RBRACE')

    def while_stmt(self):
        """<while_stmt> ::= 'while' '(' <cond> ')' '{' <stmt_list> '}'"""
        self.match('WHILE')
        self.match('LPAREN')
        self.cond()
        self.match('RPAREN')
        self.match('LBRACE')
        self.stmt_list()
        self.match('RBRACE')

    def print_stmt(self):
        """<print_stmt> ::= 'print' '(' ID ')'"""
        # self.match('PRINT')
        # self.match('LPAREN')
        # self.match('ID')
        # self.match('RPAREN')
        # self.match('SEMICOLON')

        self.match('PRINT')
        self.match('LPAREN')
        var_name = self.current_token()[1]
        self.semantic.check_variable(var_name)
        self.match('ID')
        self.match('RPAREN')
        # self.match('SEMICOLON')
        self.intermediate_code.append(f"print {var_name}")

    def cond(self):
        """<cond> ::= <expr> <relop> <expr>"""
        self.expr()
        self.relop()
        self.expr()

    def relop(self):
        """<relop> ::= '>' | '<' | '==' | '>=' | '<='"""
        if self.current_token()[0] in ['GT', 'LT', 'EQ', 'GE', 'LE']:
            self.consume()
        else:
            raise SyntaxError(f"Unexpected token in condition: {self.current_token()}")

    def expr(self):
        """<expr> ::= <term> <expr_tail>"""
        # self.term()
        # self.expr_tail()

        left = self.term()
        return self.expr_tail(left)

    def expr_tail(self, left):
        """<expr_tail> ::= '+' <term> <expr_tail> | '-' <term> <expr_tail> | ε"""
        # if self.current_token() and self.current_token()[0] in ['PLUS', 'MINUS']:
        #     self.consume()
        #     self.term()
        #     self.expr_tail()

        

        if self.current_token() and self.current_token()[0] in ['PLUS', 'MINUS']:
            op = self.current_token()[1]
            self.consume()
            right = self.term()
            temp = self.new_temp()
            self.intermediate_code.append(f"{temp} = {left} {op} {right}")
            return self.expr_tail(temp)
        return left



    def term(self,left):
        """<term> ::= <factor> <term_tail>"""
        # self.factor()
        # self.term_tail()
        left = self.factor()
        return self.term_tail(left)

    def term_tail(self,left):
        """<term_tail> ::= '*' <factor> <term_tail> | '/' <factor> <term_tail> | ε"""
        # if self.current_token() and self.current_token()[0] in ['MULT', 'DIV']:
        #     self.consume()
        #     self.factor()
        #     self.term_tail()

        if self.current_token() and self.current_token()[0] in ['MULT', 'DIV']:
            op = self.current_token()[1]
            self.consume()
            right = self.factor()
            temp = self.new_temp()
            self.intermediate_code.append(f"{temp} = {left} {op} {right}")
            return self.term_tail(temp)
        return left

    def factor(self):
        """<factor> ::= ID | NUM | '(' <expr> ')'"""
        # if self.current_token()[0] == 'ID':
        #     self.match('ID')
        # elif self.current_token()[0] == 'NUM':
        #     self.match('NUM')
        # elif self.current_token()[0] == 'LPAREN':
        #     self.match('LPAREN')
        #     self.expr()
        #     self.match('RPAREN')
        # else:
        #     raise SyntaxError(f"Unexpected token in factor: {self.current_token()}")

        token = self.current_token()
        if token[0] == 'ID':
            self.semantic.check_variable(token[1])
            self.match('ID')
            return token[1]
        elif token[0] == 'NUM':
            value = token[1]
            self.match('NUM')
            return value
        elif token[0] == 'LPAREN':
            self.match('LPAREN')
            val = self.expr()
            self.match('RPAREN')
            return val
        else:
            raise SyntaxError("Unexpected token in factor")
        
    def new_temp(self):
        if not hasattr(self, 'temp_count'):
            self.temp_count = 0
        self.temp_count += 1
        return f"t{self.temp_count}"


# Example usage
from lexer import tokenize 
from lexer import code # Import the lexer from the lexer module
tokens = tokenize(code)  # Lexical analysis
parser = Parser(tokens)  # Parsing the token stream
parser.parse()  # Start parsing
