# tokenising (lexical analysis phase)
import re

# Token specs
token_specs = [
    ('INT',       r'int'),
    ('IF',        r'if'),
    ('WHILE',     r'while'),
    ('PRINT',     r'print'),
    ('ID',        r'[a-zA-Z_][a-zA-Z0-9_]*'),
    ('NUM',       r'\d+'),
    ('GE',        r'>='),
    ('LE',        r'<='),
    ('EQ',        r'=='),
    ('GT',        r'>'),
    ('LT',        r'<'),
    ('ASSIGN',    r'='),
    ('PLUS',      r'\+'),
    ('MINUS',     r'-'),
    ('MULT',      r'\*'),
    ('DIV',       r'/'),
    ('LPAREN',    r'\('),
    ('RPAREN',    r'\)'),
    ('LBRACE',    r'\{'),
    ('RBRACE',    r'\}'),
    ('SEMICOLON', r';'),
    ('WHITESPACE', r'\s+'),
]

# Combine into one regex
token_regex = '|'.join('(?P<%s>%s)' % pair for pair in token_specs)

def tokenize(code):
    tokens = []
    for mo in re.finditer(token_regex, code):
        kind = mo.lastgroup
        value = mo.group()
        if kind == 'WHITESPACE':
            continue  # skip spaces
        tokens.append((kind, value))
    return tokens

code = '''
int x;
x = 5 + 3;
if (x > 2) {
    print(x)
}
'''

for token in tokenize(code):
    print(token)
